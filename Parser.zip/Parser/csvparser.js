var csv = require('csv'); //load csv module
var obj = csv;

function CSVdoc(fullname,eid,classe1,classe2,emailRespPai,phonePai,phoneRespMae,emailMae,emailAluno,phoneAluno,invisible,see_all){
	this.fullname = fullname;
	this.eid = eid;
	this.classe1 = classe1;
	this.classe2= classe2;
	this.emailRespPai = emailRespPai;
	this.phonePai = phonePai;
	this.phoneRespMae = phoneRespMae;
	this.emailMae = emailMae;
	this.emailAluno = emailAluno;
	this.phoneAluno = phoneAluno;
	this.invisible = invisible;
	this.see_all = see_all;
}; //define CSVdoc

var Doc = []; //receives the data from my csv file

obj.from.path('input.csv').to.array(function (data){ //Err:TypeError: Cannot read property 'path' of undefined
	 for (var index = 0; index < data.length; index++) {
	 	Doc.push(new CSVdoc(data[index][0], data[index][1], data[index][2], data[index][3], data[index][4], data[index][5], data[index][6], data[index][7], data[index][8], data[index][9], data[index][10], data[index][11]));
	 }
	 console.log(Doc); //check
});//reads the csv file and store the data in Doc[]

var http = require('http'); //load http module
var server = http.createServer(function(req,resp){
	resp.writeHead(200,{'content-type': 'application/json' });
	resp.end(JSON.stringify(Doc));
});/*create webserver, write response header with the content type as json,
end the response by sending Doc[] in JSON format.*/

 server.listen(1337); //webserver listens on 1337 port

 /*expected output
 [ Doc {fullname:'John Doe 1', eid:'1234', classe1:'Sala 1 / Sala 2',classe2:'Sala 3',emailRespPai:'johndoepai1@gmail.com',phonePai:'11 22221',phoneRespMae:'(11) 38839332',emailMae:'johndoemae1@gmail.com',emailAluno:'johndoealuno1@gmail.com',phoneAluno:'hahaha' ,invisible:'1' ,see_all: },
   Doc {fullname: ,eid: ,classe1: ,classe2: ,emailRespPai: ,phonePai: ,phoneRespMae: ,emailMae: ,emailAluno: ,phoneAluno: ,invisible: ,see_all: },
   Doc {fullname: ,eid: ,classe1: ,classe2: ,emailRespPai: ,phonePai: ,phoneRespMae: ,emailMae: ,emailAluno: ,phoneAluno: ,invisible: ,see_all: },
   Doc {fullname: ,eid: ,classe1: ,classe2: ,emailRespPai: ,phonePai: ,phoneRespMae: ,emailMae: ,emailAluno: ,phoneAluno: ,invisible: ,see_all: },
   Doc {fullname: ,eid: ,classe1: ,classe2: ,emailRespPai: ,phonePai: ,phoneRespMae: ,emailMae: ,emailAluno: ,phoneAluno: ,invisible: ,see_all: },]*/